"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { CheckCircle, Copy, Calendar, MapPin, Car } from "lucide-react"

export default function ConfirmationPage() {
  const [otp, setOtp] = useState(["", "", "", ""])
  const [isVerified, setIsVerified] = useState(false)
  const [countdown, setCountdown] = useState(30)
  const [bookingId, setBookingId] = useState("BK" + Math.floor(10000 + Math.random() * 90000))
  const [copied, setCopied] = useState(false)

  // Handle OTP input change
  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) {
      value = value.slice(0, 1)
    }

    if (value && /^[0-9]$/.test(value)) {
      const newOtp = [...otp]
      newOtp[index] = value
      setOtp(newOtp)

      // Auto-focus next input
      if (index < 3 && value) {
        const nextInput = document.getElementById(`otp-${index + 1}`)
        if (nextInput) {
          nextInput.focus()
        }
      }
    } else if (value === "") {
      const newOtp = [...otp]
      newOtp[index] = ""
      setOtp(newOtp)
    }
  }

  // Handle key down for backspace
  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`)
      if (prevInput) {
        prevInput.focus()
      }
    }
  }

  // Verify OTP
  const verifyOtp = () => {
    // In a real app, this would call an API to verify the OTP
    // For demo purposes, we'll just check if all fields are filled
    if (otp.every((digit) => digit !== "")) {
      setIsVerified(true)
    }
  }

  // Resend OTP
  const resendOtp = () => {
    setCountdown(30)
    // In a real app, this would call an API to resend the OTP
  }

  // Copy booking ID
  const copyBookingId = () => {
    navigator.clipboard.writeText(bookingId)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  // Countdown timer for resend OTP
  useEffect(() => {
    if (countdown > 0 && !isVerified) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000)
      return () => clearTimeout(timer)
    }
  }, [countdown, isVerified])

  // Booking details (would come from state/context in a real app)
  const bookingDetails = {
    location: "Central Mall Parking",
    date: "March 20, 2025",
    time: "10:00 AM - 02:00 PM",
    slot: "A4",
    vehicle: "Sedan (ABC123)",
    services: ["EV Charging"],
  }

  return (
    <div className="container py-10">
      <div className="flex flex-col gap-8 max-w-2xl mx-auto">
        {!isVerified ? (
          <Card>
            <CardHeader className="text-center">
              <CardTitle>Verify Your Booking</CardTitle>
              <CardDescription>We've sent a 4-digit OTP to your registered mobile number</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex justify-center gap-2">
                {otp.map((digit, index) => (
                  <Input
                    key={index}
                    id={`otp-${index}`}
                    className="w-12 h-12 text-center text-xl"
                    value={digit}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(index, e)}
                    maxLength={1}
                    inputMode="numeric"
                    autoComplete="one-time-code"
                  />
                ))}
              </div>

              <div className="text-center">
                {countdown > 0 ? (
                  <p className="text-sm text-muted-foreground">Resend OTP in {countdown} seconds</p>
                ) : (
                  <Button variant="link" onClick={resendOtp}>
                    Resend OTP
                  </Button>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full" onClick={verifyOtp} disabled={!otp.every((digit) => digit !== "")}>
                Verify OTP
              </Button>
            </CardFooter>
          </Card>
        ) : (
          <Card>
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <CheckCircle className="h-16 w-16 text-green-500" />
              </div>
              <CardTitle>Booking Confirmed!</CardTitle>
              <CardDescription>Your parking slot has been successfully booked</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div className="font-medium">Booking ID: {bookingId}</div>
                <Button variant="ghost" size="icon" onClick={copyBookingId} className="h-8 w-8">
                  {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                  <span className="sr-only">Copy booking ID</span>
                </Button>
              </div>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">{bookingDetails.location}</p>
                    <p className="text-sm text-muted-foreground">Slot: {bookingDetails.slot}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Calendar className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">{bookingDetails.date}</p>
                    <p className="text-sm text-muted-foreground">{bookingDetails.time}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Car className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">{bookingDetails.vehicle}</p>
                    <p className="text-sm text-muted-foreground">Services: {bookingDetails.services.join(", ")}</p>
                  </div>
                </div>
              </div>

              <div className="p-4 border rounded-lg bg-yellow-50 text-yellow-800 dark:bg-yellow-950 dark:text-yellow-300">
                <p className="text-sm font-medium">Important Information</p>
                <ul className="text-sm mt-2 space-y-1 list-disc list-inside">
                  <li>Please arrive 10 minutes before your booking time</li>
                  <li>Show your booking ID at the entrance</li>
                  <li>Cancellations are free up to 2 hours before booking time</li>
                </ul>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col gap-2">
              <Button className="w-full" asChild>
                <Link href="/dashboard">Go to Dashboard</Link>
              </Button>
              <Button variant="outline" className="w-full" asChild>
                <Link href="/">Back to Home</Link>
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>
    </div>
  )
}

