"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { CalendarIcon, Zap, Droplets } from "lucide-react"
import ParkingMap from "@/components/parking-map"

export default function BookingPage() {
  const router = useRouter()
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [location, setLocation] = useState("")
  const [startTime, setStartTime] = useState("")
  const [endTime, setEndTime] = useState("")
  const [duration, setDuration] = useState("2")
  const [vehicleType, setVehicleType] = useState("sedan")
  const [licensePlate, setLicensePlate] = useState("")
  const [services, setServices] = useState({
    evCharging: false,
    carWash: false,
  })
  const [step, setStep] = useState(1)
  const [selectedSlot, setSelectedSlot] = useState("")

  const handleContinue = () => {
    if (step < 3) {
      setStep(step + 1)
    } else {
      // Submit booking
      router.push("/book/payment")
    }
  }

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1)
    }
  }

  const locations = [
    { id: "loc1", name: "Central Mall Parking" },
    { id: "loc2", name: "Downtown Parking Complex" },
    { id: "loc3", name: "Airport Parking" },
    { id: "loc4", name: "Shopping Mall Parking" },
    { id: "loc5", name: "City Center Parking" },
  ]

  const timeSlots = [
    "08:00 AM",
    "09:00 AM",
    "10:00 AM",
    "11:00 AM",
    "12:00 PM",
    "01:00 PM",
    "02:00 PM",
    "03:00 PM",
    "04:00 PM",
    "05:00 PM",
    "06:00 PM",
    "07:00 PM",
    "08:00 PM",
  ]

  return (
    <div className="container py-10">
      <div className="flex flex-col gap-8 max-w-4xl mx-auto">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold">Book a Parking Spot</h1>
          <p className="text-muted-foreground">Fill in the details to book your parking spot</p>
        </div>

        <div className="flex justify-between mb-8">
          <div className="flex items-center gap-2">
            <div
              className={`rounded-full h-8 w-8 flex items-center justify-center ${step >= 1 ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}
            >
              1
            </div>
            <span className={step >= 1 ? "font-medium" : "text-muted-foreground"}>Location & Time</span>
          </div>
          <div className="h-0.5 flex-1 bg-muted self-center mx-4" />
          <div className="flex items-center gap-2">
            <div
              className={`rounded-full h-8 w-8 flex items-center justify-center ${step >= 2 ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}
            >
              2
            </div>
            <span className={step >= 2 ? "font-medium" : "text-muted-foreground"}>Slot Selection</span>
          </div>
          <div className="h-0.5 flex-1 bg-muted self-center mx-4" />
          <div className="flex items-center gap-2">
            <div
              className={`rounded-full h-8 w-8 flex items-center justify-center ${step >= 3 ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}
            >
              3
            </div>
            <span className={step >= 3 ? "font-medium" : "text-muted-foreground"}>Vehicle & Services</span>
          </div>
        </div>

        {step === 1 && (
          <Card>
            <CardHeader>
              <CardTitle>Location & Time</CardTitle>
              <CardDescription>Select your preferred parking location and time</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="location">Parking Location</Label>
                <Select value={location} onValueChange={setLocation}>
                  <SelectTrigger id="location">
                    <SelectValue placeholder="Select a location" />
                  </SelectTrigger>
                  <SelectContent>
                    {locations.map((loc) => (
                      <SelectItem key={loc.id} value={loc.id}>
                        {loc.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : "Select a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      initialFocus
                      disabled={(date) => date < new Date()}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="start-time">Start Time</Label>
                  <Select value={startTime} onValueChange={setStartTime}>
                    <SelectTrigger id="start-time">
                      <SelectValue placeholder="Select time" />
                    </SelectTrigger>
                    <SelectContent>
                      {timeSlots.map((time) => (
                        <SelectItem key={time} value={time}>
                          {time}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (hours)</Label>
                  <Select value={duration} onValueChange={setDuration}>
                    <SelectTrigger id="duration">
                      <SelectValue placeholder="Select duration" />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5, 6, 8, 10, 12].map((hours) => (
                        <SelectItem key={hours} value={hours.toString()}>
                          {hours} {hours === 1 ? "hour" : "hours"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={handleContinue} disabled={!location || !date || !startTime || !duration}>
                Continue
              </Button>
            </CardFooter>
          </Card>
        )}

        {step === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>Select a Parking Slot</CardTitle>
              <CardDescription>Choose your preferred parking slot from the available options</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <ParkingMap onSelectSlot={setSelectedSlot} selectedSlot={selectedSlot} />

              {selectedSlot && (
                <div className="p-4 border rounded-lg bg-muted/50">
                  <h3 className="font-medium mb-2">Selected Slot: {selectedSlot}</h3>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>Floor: Ground Floor</p>
                    <p>Type: Standard</p>
                    <p>Distance to Exit: 50m</p>
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={handleBack}>
                Back
              </Button>
              <Button onClick={handleContinue} disabled={!selectedSlot}>
                Continue
              </Button>
            </CardFooter>
          </Card>
        )}

        {step === 3 && (
          <Card>
            <CardHeader>
              <CardTitle>Vehicle & Additional Services</CardTitle>
              <CardDescription>Enter your vehicle details and select additional services</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="license-plate">License Plate Number</Label>
                <Input
                  id="license-plate"
                  placeholder="e.g., ABC123"
                  value={licensePlate}
                  onChange={(e) => setLicensePlate(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>Vehicle Type</Label>
                <RadioGroup value={vehicleType} onValueChange={setVehicleType}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="sedan" id="sedan" />
                    <Label htmlFor="sedan">Sedan</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="suv" id="suv" />
                    <Label htmlFor="suv">SUV</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="hatchback" id="hatchback" />
                    <Label htmlFor="hatchback">Hatchback</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="other" id="other" />
                    <Label htmlFor="other">Other</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label>Additional Services</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="ev-charging"
                      checked={services.evCharging}
                      onCheckedChange={(checked) => setServices({ ...services, evCharging: checked === true })}
                    />
                    <Label htmlFor="ev-charging" className="flex items-center">
                      <Zap className="mr-2 h-4 w-4" /> EV Charging (+$10)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="car-wash"
                      checked={services.carWash}
                      onCheckedChange={(checked) => setServices({ ...services, carWash: checked === true })}
                    />
                    <Label htmlFor="car-wash" className="flex items-center">
                      <Droplets className="mr-2 h-4 w-4" /> Car Wash (+$15)
                    </Label>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={handleBack}>
                Back
              </Button>
              <Button onClick={handleContinue} disabled={!licensePlate}>
                Proceed to Payment
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>
    </div>
  )
}

