"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Clock, Car, Zap, Droplets } from "lucide-react"
import BookingHistory from "@/components/booking-history"
import { Badge } from "@/components/ui/badge"

export default function Dashboard() {
  const [activeBookings, setActiveBookings] = useState([
    {
      id: "BK12345",
      location: "Central Mall Parking",
      date: "2025-03-20",
      startTime: "10:00 AM",
      endTime: "02:00 PM",
      status: "active",
      services: ["ev-charging"],
    },
  ])

  const [upcomingBookings, setUpcomingBookings] = useState([
    {
      id: "BK12346",
      location: "Downtown Parking Complex",
      date: "2025-03-25",
      startTime: "09:00 AM",
      endTime: "11:00 AM",
      status: "upcoming",
      services: ["car-wash"],
    },
  ])

  return (
    <div className="container py-10">
      <div className="flex flex-col gap-8">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Manage your parking bookings and account</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>Book a parking spot or manage your bookings</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Link href="/book">
                <Button className="w-full h-24 text-lg" size="lg">
                  <Car className="mr-2 h-5 w-5" /> Book a Parking Spot
                </Button>
              </Link>
              <Link href="/bookings">
                <Button className="w-full h-24 text-lg" variant="outline" size="lg">
                  <Clock className="mr-2 h-5 w-5" /> Manage Bookings
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Account Summary</CardTitle>
              <CardDescription>Your account information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Name</p>
                <p>John Doe</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Email</p>
                <p>john.doe@example.com</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Member Since</p>
                <p>March 2025</p>
              </div>
            </CardContent>
            <CardFooter>
              <Link href="/profile">
                <Button variant="outline" size="sm">
                  Edit Profile
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Your Bookings</CardTitle>
            <CardDescription>View and manage your active and upcoming bookings</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="active" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="active">Active</TabsTrigger>
                <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                <TabsTrigger value="history">History</TabsTrigger>
              </TabsList>
              <TabsContent value="active" className="pt-4">
                {activeBookings.length > 0 ? (
                  <div className="space-y-4">
                    {activeBookings.map((booking) => (
                      <div
                        key={booking.id}
                        className="flex flex-col md:flex-row justify-between items-start md:items-center p-4 border rounded-lg"
                      >
                        <div className="space-y-2 mb-4 md:mb-0">
                          <div className="flex items-center">
                            <h3 className="font-medium">{booking.location}</h3>
                            <Badge className="ml-2">Active</Badge>
                          </div>
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Calendar className="mr-2 h-4 w-4" />
                            {booking.date}
                          </div>
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Clock className="mr-2 h-4 w-4" />
                            {booking.startTime} - {booking.endTime}
                          </div>
                          <div className="flex items-center gap-2">
                            {booking.services.includes("ev-charging") && (
                              <Badge variant="outline" className="flex items-center gap-1">
                                <Zap className="h-3 w-3" /> EV Charging
                              </Badge>
                            )}
                            {booking.services.includes("car-wash") && (
                              <Badge variant="outline" className="flex items-center gap-1">
                                <Droplets className="h-3 w-3" /> Car Wash
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex gap-2 w-full md:w-auto">
                          <Button variant="outline" size="sm" className="flex-1 md:flex-none">
                            Extend
                          </Button>
                          <Button variant="destructive" size="sm" className="flex-1 md:flex-none">
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No active bookings</p>
                    <Link href="/book" className="mt-4 inline-block">
                      <Button>Book Now</Button>
                    </Link>
                  </div>
                )}
              </TabsContent>
              <TabsContent value="upcoming" className="pt-4">
                {upcomingBookings.length > 0 ? (
                  <div className="space-y-4">
                    {upcomingBookings.map((booking) => (
                      <div
                        key={booking.id}
                        className="flex flex-col md:flex-row justify-between items-start md:items-center p-4 border rounded-lg"
                      >
                        <div className="space-y-2 mb-4 md:mb-0">
                          <div className="flex items-center">
                            <h3 className="font-medium">{booking.location}</h3>
                            <Badge variant="outline" className="ml-2">
                              Upcoming
                            </Badge>
                          </div>
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Calendar className="mr-2 h-4 w-4" />
                            {booking.date}
                          </div>
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Clock className="mr-2 h-4 w-4" />
                            {booking.startTime} - {booking.endTime}
                          </div>
                          <div className="flex items-center gap-2">
                            {booking.services.includes("ev-charging") && (
                              <Badge variant="outline" className="flex items-center gap-1">
                                <Zap className="h-3 w-3" /> EV Charging
                              </Badge>
                            )}
                            {booking.services.includes("car-wash") && (
                              <Badge variant="outline" className="flex items-center gap-1">
                                <Droplets className="h-3 w-3" /> Car Wash
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex gap-2 w-full md:w-auto">
                          <Button variant="outline" size="sm" className="flex-1 md:flex-none">
                            Modify
                          </Button>
                          <Button variant="destructive" size="sm" className="flex-1 md:flex-none">
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No upcoming bookings</p>
                    <Link href="/book" className="mt-4 inline-block">
                      <Button>Book Now</Button>
                    </Link>
                  </div>
                )}
              </TabsContent>
              <TabsContent value="history" className="pt-4">
                <BookingHistory />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

