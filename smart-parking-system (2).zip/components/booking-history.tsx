"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Calendar, Clock } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export default function BookingHistory() {
  const [pastBookings, setPastBookings] = useState([
    {
      id: "BK12340",
      location: "Airport Parking",
      date: "2025-02-15",
      startTime: "08:00 AM",
      endTime: "06:00 PM",
      status: "completed",
      services: [],
    },
    {
      id: "BK12341",
      location: "City Center Parking",
      date: "2025-02-10",
      startTime: "10:00 AM",
      endTime: "01:00 PM",
      status: "completed",
      services: ["car-wash"],
    },
    {
      id: "BK12342",
      location: "Shopping Mall Parking",
      date: "2025-01-25",
      startTime: "02:00 PM",
      endTime: "07:00 PM",
      status: "completed",
      services: ["ev-charging"],
    },
  ])

  return (
    <div>
      {pastBookings.length > 0 ? (
        <div className="space-y-4">
          {pastBookings.map((booking) => (
            <div
              key={booking.id}
              className="flex flex-col md:flex-row justify-between items-start md:items-center p-4 border rounded-lg"
            >
              <div className="space-y-2 mb-4 md:mb-0">
                <div className="flex items-center">
                  <h3 className="font-medium">{booking.location}</h3>
                  <Badge variant="secondary" className="ml-2">
                    Completed
                  </Badge>
                </div>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Calendar className="mr-2 h-4 w-4" />
                  {booking.date}
                </div>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Clock className="mr-2 h-4 w-4" />
                  {booking.startTime} - {booking.endTime}
                </div>
              </div>
              <Button variant="outline" size="sm">
                Book Again
              </Button>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No booking history</p>
        </div>
      )}
    </div>
  )
}

