"use client"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface ParkingMapProps {
  onSelectSlot: (slot: string) => void
  selectedSlot: string
}

export default function ParkingMap({ onSelectSlot, selectedSlot }: ParkingMapProps) {
  // Simulated parking slots with availability status
  const parkingSlots = [
    { id: "A1", available: true },
    { id: "A2", available: true },
    { id: "A3", available: false },
    { id: "A4", available: true },
    { id: "A5", available: true },
    { id: "B1", available: true },
    { id: "B2", available: false },
    { id: "B3", available: false },
    { id: "B4", available: true },
    { id: "B5", available: true },
    { id: "C1", available: true },
    { id: "C2", available: true },
    { id: "C3", available: true },
    { id: "C4", available: false },
    { id: "C5", available: true },
  ]

  const rows = ["A", "B", "C"]
  const cols = [1, 2, 3, 4, 5]

  return (
    <div className="space-y-6">
      <div className="flex justify-center mb-4">
        <div className="flex gap-4 items-center">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-500 rounded-sm"></div>
            <span className="text-sm">Available</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-red-500 rounded-sm"></div>
            <span className="text-sm">Occupied</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-primary rounded-sm"></div>
            <span className="text-sm">Selected</span>
          </div>
        </div>
      </div>

      <div className="border rounded-lg p-6 bg-muted/30">
        <div className="flex justify-center mb-8">
          <div className="w-1/2 h-8 bg-gray-300 flex items-center justify-center font-medium rounded">
            ENTRANCE / EXIT
          </div>
        </div>

        <div className="grid grid-cols-5 gap-4">
          {rows.map((row) =>
            cols.map((col) => {
              const slotId = `${row}${col}`
              const slot = parkingSlots.find((s) => s.id === slotId)
              const isAvailable = slot?.available
              const isSelected = selectedSlot === slotId

              return (
                <Button
                  key={slotId}
                  variant="outline"
                  className={cn(
                    "h-16 font-bold",
                    isAvailable
                      ? isSelected
                        ? "bg-primary text-primary-foreground hover:bg-primary/90"
                        : "bg-green-500 text-white hover:bg-green-600"
                      : "bg-red-500 text-white cursor-not-allowed opacity-70",
                  )}
                  disabled={!isAvailable}
                  onClick={() => onSelectSlot(slotId)}
                >
                  {slotId}
                </Button>
              )
            }),
          )}
        </div>

        <div className="flex justify-center mt-8">
          <div className="w-3/4 h-8 bg-gray-300 flex items-center justify-center font-medium rounded">DRIVING LANE</div>
        </div>
      </div>
    </div>
  )
}

